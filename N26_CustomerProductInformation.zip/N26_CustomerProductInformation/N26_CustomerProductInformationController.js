({
    doInit : function(component, event, helper) {
        helper.fetchCaseDetails(component, event, helper);		
	}	
})