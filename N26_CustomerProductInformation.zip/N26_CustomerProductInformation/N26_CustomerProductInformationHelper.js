({
	myFuntion : function(component, event, helper) {
     
	}
})