({
	fetchCaseDetails : function(component, event, helper) {
        console.log(' INSIDE HELPER ===>');
        
		// Setup the call to the Apex Controller and also pass recordId to fetch details 
		var action = component.get("c.fetchCustomerProductInformation");
        
        action.setParams({
            caseRecordId : component.get("v.recordId")
        });

		// Configure response handler 
		action.setCallback(this, function(response) {
			var state = response.getState();			
			if(state === "SUCCESS") { 
                console.log(response.getReturnValue()+'===>');
                component.set("v.caseDetails",response.getReturnValue());
                if(!$A.util.isUndefinedOrNull(response.getReturnValue().Contact.Product__r)){                	
                    component.set("v.hasProduct",'one');
                }    
            }
        });
		$A.enqueueAction(action);	
	}
})